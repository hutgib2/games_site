from os.path import join

import pygame
from pygame import image

pygame.init()
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
WINDOW_WIDTH, WINDOW_HEIGHT = screen.get_size()
pygame.display.set_caption("Space Shooter")

# import
laser_surf = image.load(join("assets", "images", "laser.png")).convert_alpha()

meteor_surf = image.load(join("assets", "images", "meteor.png")).convert_alpha()

star_surf = image.load(join("assets", "images", "star.png")).convert_alpha()

font = pygame.font.Font(join("assets", "images", "Oxanium-Bold.ttf"), 40)

explosion_frames = [
    image.load(join("assets", "images", "explosion", f"{i}.png")).convert_alpha()
    for i in range(21)
]

laser_sound = pygame.mixer.Sound(join("assets", "audio", "damage.ogg"))
laser_sound.set_volume(0.2)
explosion_sound = pygame.mixer.Sound(join("assets", "audio", "explosion.ogg"))
explosion_sound.set_volume(0.15)
game_music = pygame.mixer.Sound(join("assets", "audio", "Glorious Morning.ogg"))
game_music.set_volume(0.25)
game_music.play(loops=-1)

# sprites
all_sprites = pygame.sprite.Group()
meteor_sprites = pygame.sprite.Group()
laser_sprites = pygame.sprite.Group()
