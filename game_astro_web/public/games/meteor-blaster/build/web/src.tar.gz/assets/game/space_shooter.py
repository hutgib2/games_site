import asyncio

import pygame
from pygame import time

from game.explosion import Explosion
from game.meteor import Meteor
from game.player import Player
from game.settings import (
    WINDOW_HEIGHT,
    WINDOW_WIDTH,
    all_sprites,
    laser_sprites,
    meteor_sprites,
	meteor_surf,
    star_surf,
	font,
	explosion_frames,
)
from game.star import Star


class SpaceShooter:
    def __init__(self):
        self.running = True
        self.game_paused = False
        self.clock = pygame.time.Clock()
        self.display_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))

        # custom meteor event
        self.meteor_event = pygame.event.custom_type()
        time.set_timer(self.meteor_event, 400)

        # create stars in bg
        for i in range(20):
            Star(all_sprites, star_surf)
        self.player = Player(all_sprites)

    def collisions(self):
        collision_sprites = pygame.sprite.spritecollide(
            self.player, meteor_sprites, True, pygame.sprite.collide_mask
        )
        if collision_sprites:
            self.running = False

        for laser in laser_sprites:
            collision = pygame.sprite.spritecollide(laser, meteor_sprites, True)
            if collision:
                laser.kill()
                Explosion(explosion_frames, laser.rect.midtop, all_sprites)

    def display_score(self):
        current_time = int(pygame.time.get_ticks() / 1000)
        self.text_surf = font.render(str(current_time), True, "#F0F0F0")
        self.text_rect = self.text_surf.get_frect(midbottom=(WINDOW_WIDTH / 2, 100))
        self.display_surface.blit(self.text_surf, self.text_rect)
        pygame.draw.rect(
            self.display_surface,
            "#F0F0F0",
            self.text_rect.inflate(20, 10).move(0, -6),
            5,
            10,
        )

    async def run(self):
        while self.running:
            dt = self.clock.tick() / 1000  # getting the delta time in seconds
            await asyncio.sleep(0)

            # event tracker
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                    self.game_paused = not self.game_paused
                if event.type == pygame.QUIT:  # when x clicked , exit loop
                    self.running = False
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.running = False
                if event.type == self.meteor_event and not self.game_paused:
                    Meteor((all_sprites, meteor_sprites), meteor_surf)

            if self.game_paused:
                continue

            all_sprites.update(dt)
            self.collisions()

            # colours the background and draws the stars
            self.display_surface.fill("#3a2e3f")
            all_sprites.draw(self.display_surface)
            self.display_score()

            pygame.display.update()
