from random import randint

from pygame import sprite

from game.settings import WINDOW_HEIGHT, WINDOW_WIDTH


class Star(sprite.Sprite):
    def __init__(self, groups, surf):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_frect(
            center=(randint(0, WINDOW_WIDTH), randint(0, WINDOW_HEIGHT))
        )
