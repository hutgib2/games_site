import asyncio
import pygame
from os.path import join

pygame.mixer.pre_init(44100, -16, 2, 512)
# 44100 — sample rate (Hz). Match this to how your OGG files were exported.
# -16 — 16-bit signed audio (standard quality)
# 2 — stereo channels
# 512 — buffer size. Lowering the buffer reduces latency; 512 is typically the smallest before underrun errors occur. Raising it prevents skipping but adds latency. The value must be a power of two.

pygame.init()

try:
    pygame.mixer.SoundPatch()
except:
    pass

screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
WINDOW_WIDTH, WINDOW_HEIGHT = screen.get_size()
pygame.display.set_caption("Space Shooter")