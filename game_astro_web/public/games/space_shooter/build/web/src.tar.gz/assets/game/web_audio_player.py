import base64
from platform import window

window.eval("""
    window._audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    window._sounds = {};

    window.loadSoundFromBase64 = function(name, b64) {
        const binary = atob(b64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        window._audioCtx.decodeAudioData(bytes.buffer)
            .then(decoded => {
                window._sounds[name] = decoded;
                console.log('Loaded sound: ' + name);
            })
            .catch(err => console.error('Sound load error [' + name + ']:', err));
    };

    window.playSound = function(name) {
        const buf = window._sounds[name];
        if (!buf) { console.error('Sound not loaded: ' + name); return; }
        const src = window._audioCtx.createBufferSource();
        src.buffer = buf;
        src.connect(window._audioCtx.destination);
        src.start(0);
    };
""")

def load_sound(name, path):
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")
    window.eval(f"loadSoundFromBase64('{name}', '{b64}')")

load_sound(loadSound('damage', 'assets/damage.ogg'))
load_sound(loadSound('explosion', 'assets/explosion.ogg'))
load_sound(loadSound('music', 'assets/glorious_morning.ogg'))

def play_sound(name):
    window.eval(f"playSound('{name}')")