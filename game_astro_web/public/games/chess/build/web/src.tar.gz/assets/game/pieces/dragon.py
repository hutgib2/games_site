from game.settings import *
from game.pieces.piece import Piece


class Dragon(Piece):
    def __init__(self, id, color, coord, squares):
        super().__init__(id, 'dragon', color, coord, squares)
        self.type = "dragon"
        self.attack_range = (1,1)
        if self.color == 'white':
            self.attack_directions = [(-1, -1), (-1, 0), (-1, 1), (0, 1), (0, -1)]
        elif self.color == 'black':
            self.attack_directions = [(1, -1), (1, 0), (1, 1), (0, 1), (0, -1)]
        
        self.move_directions = [(1, -2), (1, 2), (-1, 2), (-1, -2,), (2, 1), (2, -1), (-2, 1), (-2, -1)]
        self.move_range = 1

    def attack(self, attack_coord, round_num=0):
        killed_pieces = []
        for square in self.attack_squares:
            if square.piece:
                killed_pieces.append(square.piece)
                square.piece.remove_piece()
        return killed_pieces