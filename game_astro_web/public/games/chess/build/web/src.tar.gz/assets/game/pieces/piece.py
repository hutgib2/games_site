from game.settings import *

class Piece(pygame.sprite.Sprite):
    def __init__(self, id, piece_type, color, coord, squares):
        super().__init__()
        self.id = id
        self.type = piece_type
        self.image = pygame.transform.smoothscale(PIECE_SURFS[color][self.type], (TILE_WIDTH, TILE_WIDTH))
        self.rect = self.image.get_frect()
        self.color = color
        self.squares = squares
        self.set_position(tuple(coord))
        self.attack_squares = []
        self.move_squares = []
        self.is_reloading = False
        self.is_stunned = False
        self.has_moved = False
        self.stunned_at = 0
        self.attacked_at = 0

    def set_position(self, coord):
        self.coord = coord
        self.square = self.squares[coord[0]][coord[1]] if coord else None
        self.rect = self.square.rect if coord else None

    def has_adjacent_legionary(self, square, direction):
        from game.pieces.legionary import Legionary

        if direction == (1, -1) or direction == (-1, -1):
            row = square.coord[0]
            col = square.coord[1] + 1
            if col > 7:
                return False
        
        elif direction == (1, 1) or direction == (-1, 1):
            row = square.coord[0]
            col = square.coord[1] - 1
            if col < 0:
                return False
        else:
            return False

        defending_square = self.squares[row][col]
        if defending_square.piece and type(defending_square.piece) == Legionary and defending_square.piece.color != self.color:
            return True
        return False

    def update_possible_moves(self):
        self.move_squares = []
        for direction in self.move_directions:
            i = 1
            while i <= self.move_range:
                row = self.coord[0] + direction[0] * i
                col = self.coord[1] + direction[1] * i
                i += 1

                if row < 0 or row > 7 or col < 0 or col > 7:
                    break

                square = self.squares[row][col]
                if square.piece == None:
                    self.move_squares.append(square)
                else:
                    break

    def update_attack_moves(self):
        from game.pieces.emperor import Emperor
        from game.pieces.legionary import Legionary

        self.attack_squares = []
        for direction in self.attack_directions:
            i = self.attack_range[0]
            while i <= self.attack_range[1]:
                row = self.coord[0] + direction[0] * i
                col = self.coord[1] + direction[1] * i
                i += 1

                if row < 0 or row > 7 or col < 0 or col > 7:
                    break
                
                square = self.squares[row][col]
                if square.piece == None:
                    self.attack_squares.append(square)
                elif square.piece.color != self.color:
                    if type(square.piece) == Legionary:
                        if direction == (-1, 0) and self.color == 'white':
                            break
                        elif direction == (1, 0) and self.color == 'black':
                            break
                        elif self.has_adjacent_legionary(square, direction):
                            break
                    self.attack_squares.append(square)
                    break
                else:
                    break

    def attack(self, attack_coord, round_num=0):
        old_square = self.squares[self.coord[0]][self.coord[1]] # the attackers tile
        attack_square = self.squares[attack_coord[0]][attack_coord[1]] # the attacked tile
        killed_pieces = [attack_square.piece]
        
        attack_square.piece.remove_piece()  # eliminates the attacked piece
        attack_square.piece = old_square.piece  # replaced attacked piece with attacker piece
        old_square.piece = None  # has the attacker's tile empty
        attack_square.piece.set_position(attack_square.coord)  # sets position of the attacked tile piece
        return killed_pieces

    def remove_piece(self):
        if self.square.piece:
            self.square.piece = None
        self.set_position(None)
        self.kill()

    def get_state(self):
        return {
            "id": self.id,
            "coord": self.coord,
            "type": self.type,
            "color": self.color,
            "is_stunned": self.is_stunned,
            "is_reloading": self.is_reloading,
            "stunned_at": self.stunned_at,
            "attacked_at": self.attacked_at,
            "has_moved": self.has_moved,
        }


